using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Administration;

namespace AWP.MySitesBranding.Features.Site_ApplyCustomMasterPage
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("d5c08f39-9afe-45bb-a71d-da75fed2f203")]
    public class Site_ApplyCustomMasterPageEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            //LogInfo("in FeatureActivated");
            LogError("(TODO: Should be Info Level) in FeatureActivated"); //TODO: Should be LogInfo

            SPSite siteCollection = (SPSite)properties.Feature.Parent;
            string masterUrl = SPUrlUtility.CombineUrl(siteCollection.ServerRelativeUrl, "_catalogs/masterpage/CustomMySite.master");

            foreach (SPWeb web in siteCollection.AllWebs)
            {
                try
                {
                    web.MasterUrl = masterUrl;
                    web.CustomMasterUrl = masterUrl;
                    web.Update();
                }
                catch (Exception ex)
                {
                    LogError(ex);
                    
                    throw;
                }
                finally
                {
                    if (web != null)
                        web.Dispose();
                }

            }
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            LogInfo("in FeatureDeactivating");
            LogError("(TODO: Should be Info Level) in FeatureDeactivating"); //TODO: Should be LogInfo

            SPSite siteCollection = (SPSite)properties.Feature.Parent;
            string masterUrl = SPUrlUtility.CombineUrl(siteCollection.ServerRelativeUrl, "_catalogs/masterpage/mysite15.master");

            foreach (SPWeb web in siteCollection.AllWebs)
            {
                try
                {
                    web.MasterUrl = masterUrl;
                    web.CustomMasterUrl = masterUrl;
                    web.Update();
                }
                catch (Exception ex)
                {
                    LogError(ex);
                    throw;
                }
                finally
                {
                    if (web != null)
                        web.Dispose();
                }
            }
        }

        private void LogInfo(string msg)
        {
            SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
            diagSvc.WriteTrace(0,
                new SPDiagnosticsCategory("Info message", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium,
                "in Site_ApplyCustomMasterPageEventReceiver: {0}", msg);
        }

        private void LogError(string msg)
        {
            SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
            diagSvc.WriteTrace(0,
                new SPDiagnosticsCategory("Error message", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected,
                "in ER_MySite_ElementsWebProvisioned: {0}", msg);
        }

        private void LogError(Exception ex)
        {
            SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
            diagSvc.WriteTrace(0, 
                new SPDiagnosticsCategory("Error message", TraceSeverity.Monitorable, EventSeverity.Error), TraceSeverity.Monitorable,
                    "Houston, we have a problem in Site_ApplyCustomMasterPageEventReceiver event: {0}---{1}", ex.InnerException, ex.StackTrace);
        }

        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
