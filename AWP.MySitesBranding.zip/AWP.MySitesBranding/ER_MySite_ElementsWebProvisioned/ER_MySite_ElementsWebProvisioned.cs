﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Administration;

namespace AWP.MySitesBranding.ER_MySite_ElementsWebProvisioned
{
    /// <summary>
    /// Web Events
    /// </summary>
    public class ER_MySite_ElementsWebProvisioned : SPWebEventReceiver
    {
        /// <summary>
        /// A site was provisioned.
        /// </summary>
        //public override void WebProvisioned(SPWebEventProperties properties)
        //{
        //    base.WebProvisioned(properties);
        //}

        public override void WebProvisioned(SPWebEventProperties properties)
        {
            SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;

            //LogInfo("in FeatureActivated");
            LogError("in FeatureActivated"); //TODO: Make it LogInfo again!!

            try
            {
                base.WebProvisioned(properties); // TODO: is this needed?
                SPWeb web = properties.Web;
                SPWeb rootWeb = web.Site.RootWeb;
                web.MasterUrl = rootWeb.MasterUrl;
                web.CustomMasterUrl = rootWeb.CustomMasterUrl;
                web.Update();
            }
            catch (Exception ex)
            {
                LogError(ex, "Houston, we have a problem in WebProvisioned event: {0}---{1}");
            }
        }

        private void LogInfo(string msg)
        {
            SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
            diagSvc.WriteTrace(0,
                new SPDiagnosticsCategory("Info message", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium,
                "in ER_MySite_ElementsWebProvisioned: {0}", msg);
        }

        private void LogError(string msg)
        {
            SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
            diagSvc.WriteTrace(0,
                new SPDiagnosticsCategory("Error message", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected,
                "in ER_MySite_ElementsWebProvisioned: {0}", msg);
        }

        private void LogError(Exception ex, string formatString)
        {
            SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
            diagSvc.WriteTrace(0,
                new SPDiagnosticsCategory("Error message", TraceSeverity.Monitorable, EventSeverity.Error), TraceSeverity.Monitorable,
                    formatString, ex.InnerException, ex.StackTrace);
        }

    }
}