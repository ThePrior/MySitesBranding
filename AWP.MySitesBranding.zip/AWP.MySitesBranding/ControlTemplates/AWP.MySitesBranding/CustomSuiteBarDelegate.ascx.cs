﻿using Microsoft.SharePoint;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace AWP.MySitesBranding.ControlTemplates.AWP.MySitesBranding
{
    public partial class CustomSuiteBarDelegate : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
